//
//  NewViewController.m
//  FirstApp
//
//  Created by fission on 3/21/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import "NewViewController.h"

@interface NewViewController ()

@end

@implementation NewViewController
@synthesize delegate;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"the delegate is :%@ ", delegate);

    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)firstAction:(id)sender {
    
    [delegate myFirstRequiredMethod:self];
    [delegate thirdMethod];
    
    
}

- (IBAction)secondAction:(id)sender {
    [delegate secondMethod];
}
-(NSArray *)thirdMethod
{
    NSArray *a = [[NSArray alloc]initWithObjects:@"one",@"two", nil];
    return a;
    

}

@end
