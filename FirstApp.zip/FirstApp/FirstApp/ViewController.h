//
//  ViewController.h
//  FirstApp
//
//  Created by fission on 3/10/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewViewController.h"
@interface ViewController : UIViewController<MyProtocal>

@property(strong,nonatomic) NewViewController *vcNew;

@end

