//
//  AppDelegate.h
//  FirstApp
//
//  Created by fission on 3/10/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

