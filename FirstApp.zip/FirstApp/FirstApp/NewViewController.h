//
//  NewViewController.h
//  FirstApp
//
//  Created by fission on 3/21/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import <UIKit/UIKit.h>


@class NewViewController;
@protocol MyProtocal

@optional
-(void)myFirstRequiredMethod:(NewViewController *)myclass;
@optional
-(void)secondMethod;
-(NSArray *)thirdMethod;


@end


@interface NewViewController : UIViewController
@property (nonatomic, weak) id <MyProtocal> delegate;


@end
