//
//  Topics.h
//  FirstApp
//
//  Created by fission on 3/28/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Topics : NSObject

@property(retain,nonatomic) NSString *urlkey;
@property(retain,nonatomic) NSString *name;
@property(nonatomic,assign) int idtypr;

@end
