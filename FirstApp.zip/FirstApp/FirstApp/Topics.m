//
//  Topics.m
//  FirstApp
//
//  Created by fission on 3/28/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import "Topics.h"

@implementation Topics

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
    }
    return self;
}

@end
