//
//  ViewController.m
//  FirstApp
//
//  Created by fission on 3/10/16.
//  Copyright © 2016 fission. All rights reserved.
//

#import "ViewController.h"
#import "Topics.h"
@interface ViewController ()
{
    int x;
    float y;
    NSString *str;
    char c;
    NSInteger temoInteger;
    BOOL b;
    NSArray *tabularArray;
    NSDictionary *meetupResult;
    
    NSMutableArray *globalMeetupArray;


    
}
@property (weak, nonatomic) IBOutlet UITableView *showTasksTableView;
@property (weak, nonatomic) IBOutlet UIButton *showSeconViewController;
- (IBAction)ShowSeconView:(id)sender;

@end

@implementation ViewController
@synthesize vcNew;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    NSArray *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *path =  [docPath objectAtIndex:0];
    
    NSArray *arr = [[NSArray alloc]initWithObjects:@"one ",@"two",@"three",@"four", nil];
    NSString *tempPath = [path stringByAppendingPathComponent:@"movies.plist"];
    
    if ([arr writeToFile:tempPath atomically:YES]) {
        NSLog(@"sucessfully added");
    }
    else
    {
        NSLog(@"failed ");
    }
    
   NSString *peopleResourcePath =  [[NSBundle mainBundle]pathForResource:@"People" ofType:@"json"];
    
    
    NSFileManager *manager = [NSFileManager defaultManager];
    
    if ([manager fileExistsAtPath:tempPath]) {
        
        
    }
    else
    {
    
    }
    

    
    NSURLSession *imgsession =[NSURLSession sharedSession];
    NSString *imageUrl = @"http://placekitten.com/1000/1000";
    NSURLSessionDataTask* loadDataTask = [imgsession dataTaskWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:imageUrl]] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        UIImage *downloadedImage = [UIImage imageWithData:data];
        NSLog(@"ImageSize: %f, %f", downloadedImage.size.width, downloadedImage.size.height);
        NSLog(@"DiskCache: %lu of %lu", (unsigned long)[[NSURLCache sharedURLCache] currentDiskUsage], (unsigned long)[[NSURLCache sharedURLCache] diskCapacity]);
        NSLog(@"MemoryCache: %lu of %lu", (unsigned long)[[NSURLCache sharedURLCache] currentMemoryUsage], (unsigned long)[[NSURLCache sharedURLCache] memoryCapacity]);
    }];
    [loadDataTask resume];
    
    
    
    globalMeetupArray = [NSMutableArray new];
    
    tabularArray =   [[NSArray alloc]initWithObjects:@"one",@"two", nil];
    meetupResult = [NSDictionary new];
    // step1 (Accessing data from the server to the local client)
    NSString *urlString = @"https://api.meetup.com/2/groups?offset=0&format=json&lon=-0.1337&photo-host=secure&page=1&radius=25.0&fields=&lat=51.50998&order=id&desc=false&sig_id=201843878&sig=dc013654bef4dac6d4253d016fc6eb0b11ecb635";
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithURL:url completionHandler:^(NSData  *data, NSURLResponse  *response, NSError  *error) {
        NSLog(@"data is %@", data);
        NSError *err;
        meetupResult = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&err];
        NSLog(@"meetupResult::%@", meetupResult);
        NSMutableArray *globalMeetup = [NSMutableArray new];
        globalMeetup = [[[meetupResult objectForKey:@"results"]objectAtIndex:0]valueForKey:@"topics"];
        
        Topics *topics = [Topics new];
        
        for (NSDictionary *dict in globalMeetup) {
         topics.urlkey =  [dict valueForKey:@"urlkey"];
         topics.name =  [dict valueForKey:@"name"];
         topics.idtypr = (int)[[dict valueForKey:@"id"] integerValue];
        [globalMeetupArray addObject:topics];
            

        }
        
        NSLog(@"globalMeetupArray is %@", globalMeetupArray);
        
        
        [self.showTasksTableView reloadData];
    }];
   
    [task resume];

    
    
//    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
//                                          {
//                                                                                                     NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
//                                                                                                     NSLog(@"%@", json);
//                                                                                                     }];
//    
//                                      [dataTask resume];
    b = NO;
    
   
    if (b){

    NSLog(@"The integer variable is %d", x);
    
    NSLog(@"The integer variable is %f", y);

    NSLog(@"The integer variable is %c", c);

    NSLog(@"The integer variable is %@", str);
          
    

    }
    else{
        NSLog(@"The integer variable is %ld", (long)temoInteger);

    
    }

    // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    x = 10;
    y = 9.6;
    c = 'b';
    str = @"narsimha";
    temoInteger = 10000;
    
    NSLog(@"The integer variable is %d", x);
    
    NSLog(@"The integer variable is %f", y);
    
    NSLog(@"The integer variable is %c", c);
    
    NSLog(@"The integer variable is %@", str);
    
    NSLog(@"The integer variable is %ld", (long)temoInteger);


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated
{

// viewdidapper called
    NSLog(@"viewdidapper called");
    str = @"viewDidAppear";

    NSLog(@"viewDidAppear called : %@",str);

    
    
    
}


-(void)viewDidDisappear:(BOOL)animated
{
    str = @"viewDidDisappear";
    
    NSLog(@"viewDidDisappear called : %@",str);


    

}


-(void)viewWillDisappear:(BOOL)animated
{
    str = @"viewWillDisappear";
    
    NSLog(@"viewWillDisappear called : %@",str);
}
- (IBAction)ShowSeconView:(id)sender {
    
   self.vcNew = [[NewViewController alloc]initWithNibName:@"NewViewController" bundle:nil];
    self.vcNew.delegate = self;

    [self presentViewController:self.vcNew animated:YES completion:nil];
    
}

-(void)myFirstRequiredMethod:(NewViewController *)myclass
{
    NSLog(@"MyFirstmethod");
    
}
-(void)secondMethod;
{
    NSLog(@"my second method");
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    /*
     *   This is an important bit, it asks the table view if it has any available cells
     *   already created which it is not using (if they are offScreen), so that it can
     *   reuse them (saving the time of alloc/init/load from xib a new cell ).
     *   The identifier is there to differentiate between different types of cells
     *   (you can display different types of cells in the same table view)
     */
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    
    /*
     *   If the cell is nil it means no cell was available for reuse and that we should
     *   create a new one.
     */
    if (cell == nil) {
        
        /*
         *   Actually create a new cell (with an identifier so that it can be dequeued).
         */
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyIdentifier"];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
   // cell.textLabel.text  =  [tabularArray objectAtIndex:indexPath.row];
  
    
    if ((meetupResult != nil) && (meetupResult.count > 0 )) {
        NSMutableArray *topicsArray = [NSMutableArray new];
        topicsArray =   [[[meetupResult objectForKey:@"results"]objectAtIndex:0]valueForKey:@"topics"];
        NSLog(@"topics is %@", topicsArray);
        
        cell.textLabel.text = [NSString stringWithFormat:@"urlkey:%@ -> name:%@ -> id:%d",((Topics *)[globalMeetupArray objectAtIndex:indexPath.row]).urlkey, ((Topics *)[globalMeetupArray objectAtIndex:indexPath.row]).name, ((Topics *)[globalMeetupArray objectAtIndex:indexPath.row]).idtypr];
    }
  
    
    
    
    return cell;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return tabularArray.count;
}

@end
